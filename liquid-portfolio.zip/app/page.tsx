"use client"

import { useState, useEffect } from "react"
import { ArrowDown, Code, ExternalLink, Github, Mail, User } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export default function Portfolio() {
  const [scrollY, setScrollY] = useState(0)
  const [activeSection, setActiveSection] = useState("home")
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)

      // Update active section based on scroll position
      const sections = ["home", "about", "projects", "skills", "contact"]
      for (const section of sections) {
        const element = document.getElementById(section)
        if (element) {
          const rect = element.getBoundingClientRect()
          if (rect.top <= 100 && rect.bottom >= 100) {
            setActiveSection(section)
            break
          }
        }
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      window.scrollTo({
        top: element.offsetTop,
        behavior: "smooth",
      })
    }
    setMenuOpen(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-cyan-950 to-slate-900 text-white overflow-hidden">
      {/* Liquid background elements */}
      <div className="fixed inset-0 -z-10 overflow-hidden">
        <div
          className="absolute w-[800px] h-[800px] rounded-full bg-cyan-500/10 blur-3xl"
          style={{
            top: `${Math.sin(scrollY * 0.001) * 20 + 10}%`,
            left: `${Math.cos(scrollY * 0.002) * 30 + 20}%`,
            transform: `scale(${1 + Math.sin(scrollY * 0.0005) * 0.2})`,
            opacity: 0.5 + Math.sin(scrollY * 0.001) * 0.2,
          }}
        />
        <div
          className="absolute w-[600px] h-[600px] rounded-full bg-blue-500/10 blur-3xl"
          style={{
            top: `${Math.cos(scrollY * 0.002) * 20 + 50}%`,
            right: `${Math.sin(scrollY * 0.001) * 30 + 10}%`,
            transform: `scale(${1 + Math.cos(scrollY * 0.0005) * 0.2})`,
            opacity: 0.4 + Math.cos(scrollY * 0.001) * 0.2,
          }}
        />
        <div
          className="absolute w-[500px] h-[500px] rounded-full bg-teal-500/10 blur-3xl"
          style={{
            bottom: `${Math.sin(scrollY * 0.001) * 20 + 5}%`,
            left: `${Math.cos(scrollY * 0.002) * 30 + 40}%`,
            transform: `scale(${1 + Math.sin(scrollY * 0.0008) * 0.3})`,
            opacity: 0.3 + Math.sin(scrollY * 0.002) * 0.2,
          }}
        />
      </div>

      {/* Navigation */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-slate-900/80 backdrop-blur-md border-b border-cyan-500/20">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link
            href="/"
            className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-teal-400"
          >
            DevFlow
          </Link>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2 rounded-full bg-cyan-900/50 hover:bg-cyan-800/50 transition-colors"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            <div className="w-6 flex flex-col gap-1.5">
              <span
                className={cn(
                  "block h-0.5 bg-cyan-400 transition-all duration-300",
                  menuOpen ? "rotate-45 translate-y-2" : "",
                )}
              />
              <span
                className={cn(
                  "block h-0.5 bg-cyan-400 transition-all duration-300",
                  menuOpen ? "opacity-0" : "opacity-100",
                )}
              />
              <span
                className={cn(
                  "block h-0.5 bg-cyan-400 transition-all duration-300",
                  menuOpen ? "-rotate-45 -translate-y-2" : "",
                )}
              />
            </div>
          </button>

          {/* Desktop navigation */}
          <nav className="hidden md:flex gap-8">
            {["home", "about", "projects", "skills", "contact"].map((section) => (
              <button
                key={section}
                onClick={() => scrollToSection(section)}
                className={cn(
                  "capitalize relative py-1 px-2 transition-colors",
                  activeSection === section ? "text-cyan-400" : "text-slate-300 hover:text-white",
                )}
              >
                {section}
                {activeSection === section && (
                  <span className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-cyan-400 to-teal-400 rounded-full" />
                )}
              </button>
            ))}
          </nav>
        </div>

        {/* Mobile menu */}
        <div
          className={cn(
            "md:hidden absolute w-full bg-slate-900/95 backdrop-blur-md border-b border-cyan-500/20 transition-all duration-300 overflow-hidden",
            menuOpen ? "max-h-[300px] py-4" : "max-h-0 py-0",
          )}
        >
          <nav className="flex flex-col gap-4 px-4">
            {["home", "about", "projects", "skills", "contact"].map((section) => (
              <button
                key={section}
                onClick={() => scrollToSection(section)}
                className={cn(
                  "capitalize py-2 px-4 rounded-lg transition-colors text-left",
                  activeSection === section
                    ? "bg-cyan-900/50 text-cyan-400"
                    : "text-slate-300 hover:bg-slate-800/50 hover:text-white",
                )}
              >
                {section}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center relative pt-16">
        <div
          className="container mx-auto px-4 py-20 flex flex-col items-center text-center"
          style={{
            transform: `translateY(${scrollY * 0.2}px)`,
            opacity: 1 - scrollY * 0.001,
          }}
        >
          <div className="relative mb-8 w-40 h-40 rounded-full overflow-hidden border-4 border-cyan-400/30 shadow-lg shadow-cyan-500/20">
            <Image
              src="/placeholder.svg?height=160&width=160"
              alt="Developer"
              width={160}
              height={160}
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-cyan-900/50" />
          </div>

          <h1 className="text-4xl md:text-6xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-teal-400">
            John Developer
          </h1>

          <h2 className="text-xl md:text-2xl mb-8 text-slate-300">Full Stack Web Developer</h2>

          <p className="max-w-2xl text-slate-300 mb-10 leading-relaxed">
            Creating fluid digital experiences that flow seamlessly between design and functionality. Specializing in
            interactive web applications with modern technologies.
          </p>

          <div className="flex flex-wrap gap-4 justify-center">
            <Button
              onClick={() => scrollToSection("projects")}
              className="bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600 text-white border-none"
            >
              View My Work
            </Button>

            <Button
              onClick={() => scrollToSection("contact")}
              variant="outline"
              className="border-cyan-500 text-cyan-400 hover:bg-cyan-950/50"
            >
              Contact Me
            </Button>
          </div>

          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
            <ArrowDown className="w-6 h-6 text-cyan-400" />
          </div>
        </div>

        {/* Liquid wave divider */}
        <div className="absolute bottom-0 left-0 w-full overflow-hidden">
          <svg viewBox="0 0 1200 120" preserveAspectRatio="none" className="w-full h-20 md:h-32">
            <path
              d="M0,0 C150,90 350,0 500,80 C650,160 750,40 900,100 C1050,160 1150,60 1200,80 L1200,120 L0,120 Z"
              className="fill-slate-900"
            />
          </svg>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-slate-900 relative">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-teal-400">
            About Me
          </h2>

          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div className="relative">
              <div className="relative z-10 rounded-lg overflow-hidden border border-cyan-500/20 shadow-xl shadow-cyan-900/20">
                <Image
                  src="/placeholder.svg?height=600&width=800"
                  alt="Developer working"
                  width={800}
                  height={600}
                  className="w-full h-auto"
                />
                <div className="absolute inset-0 bg-gradient-to-tr from-cyan-950/70 to-transparent" />
              </div>

              {/* Decorative elements */}
              <div className="absolute -top-5 -left-5 w-20 h-20 border-t-2 border-l-2 border-cyan-500/30" />
              <div className="absolute -bottom-5 -right-5 w-20 h-20 border-b-2 border-r-2 border-teal-500/30" />
            </div>

            <div
              className="space-y-6 text-slate-300"
              style={{
                transform: `translateY(${Math.max(0, (scrollY - 500) * 0.1)}px)`,
                opacity: Math.min(1, Math.max(0, (scrollY - 400) * 0.002)),
              }}
            >
              <div className="flex items-center gap-3">
                <User className="text-cyan-400" />
                <h3 className="text-xl font-semibold text-white">Who I Am</h3>
              </div>
              <p className="leading-relaxed">
                I'm a passionate web developer with over 5 years of experience creating dynamic and responsive web
                applications. My journey in web development started with a curiosity about how websites work and evolved
                into a deep love for crafting digital experiences.
              </p>

              <div className="flex items-center gap-3">
                <Code className="text-cyan-400" />
                <h3 className="text-xl font-semibold text-white">What I Do</h3>
              </div>
              <p className="leading-relaxed">
                I specialize in building modern web applications using React, Next.js, and Node.js. My approach combines
                technical expertise with an eye for design, ensuring that the websites I create are not only functional
                but also visually appealing and user-friendly.
              </p>

              <div className="pt-4">
                <Button
                  onClick={() => scrollToSection("skills")}
                  variant="outline"
                  className="border-cyan-500 text-cyan-400 hover:bg-cyan-950/50"
                >
                  My Skills
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Liquid wave divider */}
        <div className="absolute bottom-0 left-0 w-full overflow-hidden">
          <svg viewBox="0 0 1200 120" preserveAspectRatio="none" className="w-full h-20 md:h-32 rotate-180">
            <path
              d="M0,0 C150,90 350,0 500,80 C650,160 750,40 900,100 C1050,160 1150,60 1200,80 L1200,120 L0,120 Z"
              className="fill-cyan-950"
            />
          </svg>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 bg-cyan-950 relative">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-teal-400">
            My Projects
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "E-Commerce Platform",
                description: "A full-featured online store with payment processing and inventory management.",
                image: "/placeholder.svg?height=400&width=600",
                tags: ["Next.js", "Tailwind CSS", "Stripe"],
              },
              {
                title: "Portfolio Website",
                description: "A creative portfolio for a digital artist with interactive galleries.",
                image: "/placeholder.svg?height=400&width=600",
                tags: ["React", "Framer Motion", "Three.js"],
              },
              {
                title: "Task Management App",
                description: "A collaborative task manager with real-time updates and team features.",
                image: "/placeholder.svg?height=400&width=600",
                tags: ["TypeScript", "Firebase", "Material UI"],
              },
            ].map((project, index) => (
              <div
                key={index}
                className="group relative bg-slate-900/50 backdrop-blur-sm rounded-lg overflow-hidden border border-cyan-500/20 shadow-lg shadow-cyan-900/20 transition-all duration-300 hover:shadow-xl hover:shadow-cyan-700/20 hover:-translate-y-2"
                style={{
                  transform: `translateY(${Math.max(0, (scrollY - 800) * 0.1)}px)`,
                  opacity: Math.min(1, Math.max(0, (scrollY - 700) * 0.002)),
                }}
              >
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    width={600}
                    height={400}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent opacity-70" />
                </div>

                <div className="p-6 relative z-10">
                  <h3 className="text-xl font-bold mb-2 text-white">{project.title}</h3>
                  <p className="text-slate-300 mb-4">{project.description}</p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tags.map((tag, i) => (
                      <span
                        key={i}
                        className="text-xs px-2 py-1 rounded-full bg-cyan-900/50 text-cyan-300 border border-cyan-500/20"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div className="flex gap-3">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/50 p-2 h-auto"
                    >
                      <Github className="w-5 h-5" />
                      <span className="sr-only">GitHub</span>
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/50 p-2 h-auto"
                    >
                      <ExternalLink className="w-5 h-5" />
                      <span className="sr-only">Live Demo</span>
                    </Button>
                  </div>

                  {/* Liquid corner effect */}
                  <div className="absolute -bottom-2 -right-2 w-16 h-16 bg-gradient-to-tl from-cyan-500/20 to-transparent rounded-tl-full" />
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button variant="outline" className="border-cyan-500 text-cyan-400 hover:bg-cyan-900/50">
              View All Projects
            </Button>
          </div>
        </div>

        {/* Liquid wave divider */}
        <div className="absolute bottom-0 left-0 w-full overflow-hidden">
          <svg viewBox="0 0 1200 120" preserveAspectRatio="none" className="w-full h-20 md:h-32">
            <path
              d="M0,0 C150,90 350,0 500,80 C650,160 750,40 900,100 C1050,160 1150,60 1200,80 L1200,120 L0,120 Z"
              className="fill-slate-900"
            />
          </svg>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 bg-slate-900 relative">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-teal-400">
            My Skills
          </h2>

          <div className="grid md:grid-cols-2 gap-10">
            <div
              className="space-y-8"
              style={{
                transform: `translateX(${Math.min(0, (scrollY - 1500) * -0.1)}px)`,
                opacity: Math.min(1, Math.max(0, (scrollY - 1400) * 0.002)),
              }}
            >
              <div>
                <h3 className="text-xl font-bold mb-4 text-white">Frontend Development</h3>
                <div className="space-y-4">
                  {[
                    { name: "React", level: 90 },
                    { name: "Next.js", level: 85 },
                    { name: "TypeScript", level: 80 },
                    { name: "Tailwind CSS", level: 95 },
                  ].map((skill, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-1">
                        <span className="text-slate-300">{skill.name}</span>
                        <span className="text-cyan-400">{skill.level}%</span>
                      </div>
                      <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-cyan-500 to-teal-500 rounded-full"
                          style={{ width: `${skill.level}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold mb-4 text-white">Backend Development</h3>
                <div className="space-y-4">
                  {[
                    { name: "Node.js", level: 85 },
                    { name: "Express", level: 80 },
                    { name: "MongoDB", level: 75 },
                    { name: "PostgreSQL", level: 70 },
                  ].map((skill, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-1">
                        <span className="text-slate-300">{skill.name}</span>
                        <span className="text-cyan-400">{skill.level}%</span>
                      </div>
                      <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-cyan-500 to-teal-500 rounded-full"
                          style={{ width: `${skill.level}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div
              className="grid grid-cols-2 sm:grid-cols-3 gap-6"
              style={{
                transform: `translateX(${Math.min(0, (scrollY - 1500) * 0.1)}px)`,
                opacity: Math.min(1, Math.max(0, (scrollY - 1400) * 0.002)),
              }}
            >
              {[
                "JavaScript",
                "React",
                "Next.js",
                "TypeScript",
                "Node.js",
                "Tailwind CSS",
                "MongoDB",
                "Git",
                "Figma",
                "REST API",
                "GraphQL",
                "Responsive Design",
              ].map((skill, index) => (
                <div
                  key={index}
                  className="flex flex-col items-center justify-center p-4 bg-slate-800/50 backdrop-blur-sm rounded-lg border border-cyan-500/20 hover:border-cyan-500/40 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-900/20 hover:-translate-y-1"
                >
                  <div className="w-12 h-12 mb-3 rounded-full bg-cyan-900/50 flex items-center justify-center">
                    <span className="text-lg font-bold text-cyan-400">{skill.charAt(0)}</span>
                  </div>
                  <span className="text-center text-slate-300">{skill}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Liquid wave divider */}
        <div className="absolute bottom-0 left-0 w-full overflow-hidden">
          <svg viewBox="0 0 1200 120" preserveAspectRatio="none" className="w-full h-20 md:h-32 rotate-180">
            <path
              d="M0,0 C150,90 350,0 500,80 C650,160 750,40 900,100 C1050,160 1150,60 1200,80 L1200,120 L0,120 Z"
              className="fill-cyan-950"
            />
          </svg>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-cyan-950 relative">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-teal-400">
            Get In Touch
          </h2>

          <div className="grid md:grid-cols-2 gap-10 max-w-4xl mx-auto">
            <div
              className="space-y-6"
              style={{
                transform: `translateY(${Math.max(0, (scrollY - 2000) * 0.1)}px)`,
                opacity: Math.min(1, Math.max(0, (scrollY - 1900) * 0.002)),
              }}
            >
              <h3 className="text-2xl font-bold text-white">Let's Talk</h3>
              <p className="text-slate-300 leading-relaxed">
                Have a project in mind or want to discuss potential opportunities? Feel free to reach out. I'm always
                open to new challenges and collaborations.
              </p>

              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-cyan-900/50 flex items-center justify-center">
                    <Mail className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">Email</p>
                    <p className="text-white">john@developer.com</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-cyan-900/50 flex items-center justify-center">
                    <Github className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">GitHub</p>
                    <p className="text-white">github.com/johndeveloper</p>
                  </div>
                </div>
              </div>

              <div className="pt-4 flex gap-4">
                {["github", "twitter", "linkedin", "dribbble"].map((platform, index) => (
                  <Link
                    key={index}
                    href="#"
                    className="w-10 h-10 rounded-full bg-slate-800 hover:bg-cyan-900 flex items-center justify-center transition-colors"
                  >
                    <span className="sr-only">{platform}</span>
                    <div className="w-5 h-5 text-cyan-400" />
                  </Link>
                ))}
              </div>
            </div>

            <div
              className="bg-slate-900/50 backdrop-blur-sm rounded-lg p-6 border border-cyan-500/20 shadow-lg shadow-cyan-900/20"
              style={{
                transform: `translateY(${Math.max(0, (scrollY - 2000) * 0.1)}px)`,
                opacity: Math.min(1, Math.max(0, (scrollY - 1900) * 0.002)),
              }}
            >
              <form className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm text-slate-300">
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      className="w-full px-4 py-2 bg-slate-800/50 border border-cyan-900/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500/50 text-white"
                      placeholder="Your Name"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm text-slate-300">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      className="w-full px-4 py-2 bg-slate-800/50 border border-cyan-900/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500/50 text-white"
                      placeholder="Your Email"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label htmlFor="subject" className="text-sm text-slate-300">
                    Subject
                  </label>
                  <input
                    type="text"
                    id="subject"
                    className="w-full px-4 py-2 bg-slate-800/50 border border-cyan-900/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500/50 text-white"
                    placeholder="Subject"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm text-slate-300">
                    Message
                  </label>
                  <textarea
                    id="message"
                    rows={4}
                    className="w-full px-4 py-2 bg-slate-800/50 border border-cyan-900/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500/50 text-white resize-none"
                    placeholder="Your Message"
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600 text-white border-none"
                >
                  Send Message
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-slate-900 border-t border-cyan-900/30">
        <div className="container mx-auto px-4 text-center">
          <Link
            href="/"
            className="inline-block mb-6 text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-teal-400"
          >
            DevFlow
          </Link>

          <p className="text-slate-400 mb-6 max-w-md mx-auto">
            Creating fluid digital experiences that flow seamlessly between design and functionality.
          </p>

          <div className="flex justify-center gap-6 mb-6">
            {["home", "about", "projects", "skills", "contact"].map((section) => (
              <button
                key={section}
                onClick={() => scrollToSection(section)}
                className="capitalize text-sm text-slate-400 hover:text-cyan-400 transition-colors"
              >
                {section}
              </button>
            ))}
          </div>

          <div className="border-t border-slate-800 pt-6">
            <p className="text-sm text-slate-500">
              &copy; {new Date().getFullYear()} John Developer. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
